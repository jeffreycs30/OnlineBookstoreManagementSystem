// backend/routes/bookRoutes.js
const express = require('express');
const router = express.Router();
const Book = require('../models/book');

// POST route to add a new book
router.post('/', async (req, res) => {
    const { title, author, price, stock } = req.body;
    const book = new Book({ title, author, price, stock });

    try {
        await book.save();
        res.status(201).json(book);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

// GET route to fetch all books
router.get('/', async (req, res) => {
    try {
        const books = await Book.find();
        res.json(books);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

module.exports = router;
