const http = require('http');
const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const User = require('./models/User');  // Make sure you have the User model
const app = express();
app.use(express.json()); // To parse JSON body data

// Enable CORS for the frontend on 127.0.0.1:5500
app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', 'http://127.0.0.1:5500');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    next();
});

// MongoDB Connection
mongoose.connect('mongodb://localhost:27017/bookstore')
.then(() => console.log('Connected to MongoDB...'))
.catch(err => console.error('Could not connect to MongoDB...', err));

// Book Schema
const bookSchema = new mongoose.Schema({
    title: String,
    author: String,
    price: Number,
    stock: Number
});
const Book = mongoose.model('Book', bookSchema);

// User Signup
app.post('/api/signup', async (req, res) => {
    try {
        const { username, password } = req.body;
        const hashedPassword = await bcrypt.hash(password, 10);
        const user = new User({ username, password: hashedPassword });
        await user.save();
        res.status(201).send('User registered');
    } catch (error) {
        res.status(500).send('Error registering user: ' + error.message);
    }
});

// User Login
app.post('/api/login', async (req, res) => {
    const { username, password } = req.body;
    const user = await User.findOne({ username });
    if (user && await bcrypt.compare(password, user.password)) {
        res.status(200).send('Login successful');
    } else {
        res.status(401).send('Invalid username or password');
    }
});

// Add Book
app.post('/api/books', async (req, res) => {
    try {
        const { title, author, price, stock } = req.body;
        console.log('Received book data:', req.body); // Log received book data

        // Check if required fields are present
        if (!title || !author || !price || !stock) {
            return res.status(400).send('Missing required book details');
        }

        // Create new book and save to database
        const book = new Book({ title, author, price: Number(price), stock: Number(stock) });
        await book.save();  // This will store the book in MongoDB
        res.status(201).send('Book added successfully');
    } catch (error) {
        console.error('Error adding book:', error.message);
        res.status(500).send('Error adding book: ' + error.message);
    }
});

// Get Books (with optional search query)
app.get('/api/books', async (req, res) => {
    try {
        const query = req.query.query || '';
        const books = await Book.find({
            $or: [
                { title: new RegExp(query, 'i') },
                { author: new RegExp(query, 'i') }
            ]
        });
        res.send(books);
    } catch (error) {
        res.status(500).send('Error fetching books: ' + error.message);
    }
});

// Create the server and start listening
const PORT = 3000;
http.createServer(app).listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}/`);
});
