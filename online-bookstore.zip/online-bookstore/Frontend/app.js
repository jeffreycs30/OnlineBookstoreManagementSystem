const apiUrl = 'http://localhost:3000/api'; // Adjust as necessary

// Show the login form when the page loads
document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('loginForm').style.display = 'block'; // Show login form by default

    // Show signup form
    document.getElementById('showSignup').addEventListener('click', () => {
        document.getElementById('loginForm').style.display = 'none'; // Hide login form
        document.getElementById('signupForm').style.display = 'block'; // Show signup form
    });

    // Show login form
    document.getElementById('showLogin').addEventListener('click', () => {
        document.getElementById('signupForm').style.display = 'none'; // Hide signup form
        document.getElementById('loginForm').style.display = 'block'; // Show login form
    });
});

// Handle signup
document.getElementById('signupForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const username = document.getElementById('signupUsername').value;
    const password = document.getElementById('signupPassword').value;

    const response = await fetch(`${apiUrl}/signup`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
    });

    if (response.ok) {
        alert('Signup successful! You can now log in.');
        document.getElementById('signupForm').reset();
        document.getElementById('signupForm').style.display = 'none';
        document.getElementById('loginForm').style.display = 'block';
    } else {
        alert('Signup failed. Please try again.');
    }
});

// Handle login
document.getElementById('loginForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const username = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;

    const response = await fetch(`${apiUrl}/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
    });

    if (response.ok) {
        alert('Login successful!');
        document.getElementById('loginForm').style.display = 'none';
        document.getElementById('bookForm').style.display = 'block'; // Show the book form
        fetchBooks(); // Fetch existing books for the user
    } else {
        alert('Login failed. Please check your credentials.');
    }
});

// Handle adding a new book
document.getElementById('bookForm').addEventListener('submit', async function(e) {
    e.preventDefault(); // Prevent the default form submission

    // Retrieve values from the form
    const title = document.getElementById('title').value;
    const author = document.getElementById('author').value;
    const price = document.getElementById('price').value;
    const stock = document.getElementById('stock').value;

    const bookData = { title, author, price, stock };

    // Make POST request to add a new book
    const response = await fetch(`${apiUrl}/books`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(bookData),
    });

    if (response.ok) {
        alert('Book added successfully!');
        document.getElementById('bookForm').reset();
        fetchBooks(); // Fetch updated book list
    } else {
        alert('Failed to add the book.');
    }
});

// Function to fetch and display books
async function fetchBooks() {
    const response = await fetch(`${apiUrl}/books`);
    const books = await response.json();
    const bookList = document.querySelector('#bookList .list-group');
    bookList.innerHTML = ''; // Clear current list

    books.forEach(book => {
        const li = document.createElement('li');
        li.className = 'list-group-item';
        li.textContent = `${book.title} by ${book.author} - $${book.price} (Stock: ${book.stock})`;
        bookList.appendChild(li);
    });
}
